class NearestStation < ApplicationRecord
  belongs_to :property
end
