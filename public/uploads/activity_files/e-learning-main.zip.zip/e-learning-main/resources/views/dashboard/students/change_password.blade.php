@extends('templates.dashboard.students.layout')

@section('title')
	Changer mon mot de passe
@stop