@extends('templates.dashboard.students.layout')

@section('title')
	Changer mes informations
@stop