@extends('templates.dashboard.students.layout')

@section('title')
	Mes Challenges
@stop